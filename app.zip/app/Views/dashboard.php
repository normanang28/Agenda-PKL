<marquee><h1>Selamat Datang <?= session()->get('username')?>!!</h1></marquee>
